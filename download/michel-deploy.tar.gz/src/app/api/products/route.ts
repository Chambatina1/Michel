import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/* ── Embedded fallback products (when DB is unavailable) ── */
const FALLBACK_PRODUCTS = [
  {
    id: 'fp-1',
    name: 'GE Revolution CT Scanner',
    slug: 'ge-revolution-ct-scanner',
    category: 'CT',
    condition: 'Refurbished',
    price: 185000,
    description: 'The GE Revolution CT Scanner delivers exceptional image quality with its 256-slice detector and advanced iterative reconstruction technology. Designed for high-volume imaging centers, it provides fast turnaround times and reduced dose for patients. This refurbished unit has been fully inspected and calibrated to meet OEM specifications. Ideal for cardiac, neurological, and trauma imaging applications. Comes with a 12-month warranty and on-site installation support.',
    specs: '{"Detector Rows":"256 slices","Rotation Time":"0.28s","Slice Thickness":"0.625 mm","Gantry Aperture":"80 cm","Table Weight Limit":"450 lbs","Tube Heat Capacity":"8.0 MHU","Spatial Resolution":"0.24 mm","Software Version":"Revolution EVO"}',
    features: '["256-slice detector for superior image quality","Advanced iterative reconstruction (ASiR-V)","Low-dose cardiac CT angiography","One-beat cardiac imaging","Automated workflow with kV assist","Smart collimation for dose optimization"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: true,
    createdAt: '2025-01-15T10:00:00.000Z',
  },
  {
    id: 'fp-2',
    name: 'Siemens Magnetom Vida 3T MRI',
    slug: 'siemens-magnetom-vida-3t-mri',
    category: 'MRI',
    condition: 'Refurbished',
    price: 425000,
    description: 'The Siemens Magnetom Vida 3T MRI combines Tim 4G and Dot technology to deliver outstanding diagnostic confidence across all clinical applications. Its 70 cm bore provides exceptional patient comfort while maintaining high-field performance. This refurbished system features the BioMatrix technology that personalizes exams for each patient. Perfect for neurology, orthopedics, and oncology imaging. Includes comprehensive installation and training package.',
    specs: '{"Field Strength":"3.0 Tesla","Bore Size":"70 cm","Gradient Strength":"45 mT/m","Slew Rate":"200 T/m/s","Channels":"up to 128","Coils":"18-element Body, Head/Neck, Spine","Patient Weight Limit":"550 lbs","Software":"syngo MR XA30"}',
    features: '["Tim 4G integrated coil technology","BioMatrix patient-personalized imaging","70 cm patient-friendly bore","Quiet Suite for reduced acoustic noise","Dot workflow automation","Advanced diffusion and perfusion imaging"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: true,
    createdAt: '2025-01-20T10:00:00.000Z',
  },
  {
    id: 'fp-3',
    name: 'Philips IU Elite Ultrasound',
    slug: 'philips-iu-elite-ultrasound',
    category: 'Ultrasound',
    condition: 'New',
    price: 95000,
    description: 'The Philips IU Elite Ultrasound system is a premium shared-service platform designed for exceptional clinical performance. It features advanced imaging technologies including nSIGHT imaging for enhanced tissue differentiation and PureWave crystal technology for superior resolution. The system excels in abdominal, vascular, OB/GYN, and musculoskeletal imaging. Its intuitive touchscreen interface streamlines workflow for busy clinical environments.',
    specs: '{"Transducer Ports":"4 active ports","Display":"21.5" HD LCD","Imaging Modes":"B-mode, M-mode, Doppler, Harmonic","Tissue Harmonic":"nSIGHT","Frame Rate":"Up to 300 fps","Storage":"1 TB HDD + DVD-RW","Connectivity":"DICOM 3.0, USB, Ethernet","Weight":"325 lbs"}',
    features: '["nSIGHT imaging for enhanced tissue characterization","PureWave transducer technology","AutoSCAN for automated image optimization","Active Array matrix transducers","QLAB quantitative analysis","iSCAN one-touch image optimization"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: true,
    createdAt: '2025-02-01T10:00:00.000Z',
  },
  {
    id: 'fp-4',
    name: 'Zeiss Cirrus HD-OCT 6000',
    slug: 'zeiss-cirrus-hd-oct-6000',
    category: 'Ophthalmology',
    condition: 'New',
    price: 75000,
    description: 'The Zeiss Cirrus HD-OCT 6000 is the gold standard in optical coherence tomography for ophthalmic diagnostics. It provides ultra-high resolution retinal imaging with advanced segmentation algorithms for retinal nerve fiber layer and ganglion cell analysis. The system features an intuitive touchscreen interface and streamlined workflow for efficient patient throughput. Ideal for glaucoma management, retinal disease assessment, and anterior segment imaging.',
    specs: '{"Scan Speed":"68,000 A-scans/second","Axial Resolution":"5 \u03bcm","Transverse Resolution":"15 \u03bcm","Scan Depth":"2.0 mm","Scan Width":"9.0 mm","Imaging Modes":"Macula, Optic Disc, Anterior Segment, HD Angio","Eye Tracking":"TruTrack active","Display":"24" widescreen monitor"}',
    features: '["Ultra-high speed HD imaging","Advanced ganglion cell analysis (GCC)","Glaucoma progression analysis (GPA)","Anterior segment OCT module","HD Angio retinal vasculature imaging","Seamless EMR integration"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: true,
    createdAt: '2025-02-10T10:00:00.000Z',
  },
  {
    id: 'fp-5',
    name: 'Toshiba Aquilion ONE CT',
    slug: 'toshiba-aquilion-one-ct',
    category: 'CT',
    condition: 'Refurbished',
    price: 210000,
    description: 'The Toshiba Aquilion ONE CT Scanner features a 320-row detector that can image an entire organ in a single rotation, reducing motion artifacts and radiation dose significantly. Its cone-beam CT technology eliminates helical artifacts for pure volumetric imaging. This refurbished unit is ideal for cardiac, brain perfusion, and whole-organ dynamic studies. Includes full system recalibration and a 12-month parts warranty.',
    specs: '{"Detector Rows":"320 rows (0.5 mm)","Detector Coverage":"16 cm","Rotation Time":"0.275s","Slice Thickness":"0.5 mm","Gantry Aperture":"78 cm","Spatial Resolution":"0.35 mm","Tube Voltage":"80-135 kV","Software":"Vitrea workstation included"}',
    features: '["Volume CT with 16 cm coverage","Single-rotation whole-organ imaging","Ultra-low dose with AIDR 3D","Cardiac CT with 100% phase coverage","Brain perfusion in single rotation","Real-time image reconstruction"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: false,
    createdAt: '2025-02-15T10:00:00.000Z',
  },
  {
    id: 'fp-6',
    name: 'Hitachi Echelon Oval MRI',
    slug: 'hitachi-echelon-oval-mri',
    category: 'MRI',
    condition: 'Refurbished',
    price: 350000,
    description: 'The Hitachi Echelon Oval MRI features the world\'s first oval-shaped bore design, providing unmatched patient comfort with a spacious feel while maintaining 1.5T diagnostic performance. Its zero boil-off magnet technology reduces operational costs significantly. The system is ideal for claustrophobic patients, bariatric imaging, and general diagnostic use. This refurbished unit comes with updated coils and current software version.',
    specs: '{"Field Strength":"1.5 Tesla","Bore Size":"74 cm (oval)","Gradient Strength":"33 mT/m","Slew Rate":"150 T/m/s","Magnet Type":"Zero boil-off superconducting","Coils":"Body, Head, Spine, Extremity","Patient Weight Limit":"500 lbs","Software":"R5.0 workflow suite"}',
    features: '["Oval bore for maximum patient comfort","Zero boil-off magnet technology","Claustrophobic patient-friendly design","Low operating costs","Parallel imaging (SENS-itivity Encoding)","Comprehensive clinical applications package"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: false,
    createdAt: '2025-03-01T10:00:00.000Z',
  },
  {
    id: 'fp-7',
    name: 'Carestream DRX-Evolution X-Ray',
    slug: 'carestream-drx-evolution-x-ray',
    category: 'X-Ray',
    condition: 'New',
    price: 125000,
    description: 'The Carestream DRX-Evolution is a versatile digital radiography system designed for high-throughput imaging environments. It features a motorized ceiling-mounted tube stand and wireless DR detectors for flexible positioning. The system\'s intelligent software automatically optimizes image quality while minimizing dose. Perfect for hospitals, urgent care centers, and orthopedic practices requiring reliable everyday imaging.',
    specs: '{"Generator":"80 kW high-frequency","Tube":"Dual-focus X-ray tube","Detector":"Wireless DRX 3543 (35 x 43 cm)","Detectors Included":"2 wireless panels","Collimation":"Automatic multi-leaf","SID Range":"40-72 inches","Table":"4-way floating tabletop","Software":"Carestream PACS integrated"}',
    features: '["Wireless DR detector technology","Motorized tube stand positioning","Automatic exposure control (AEC)","Image processing with EVP+ software","DICOM 3.0 worklist management","Bucky wall stand for upright exams"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: false,
    createdAt: '2025-03-10T10:00:00.000Z',
  },
  {
    id: 'fp-8',
    name: 'Canon Aplio i800 Ultrasound',
    slug: 'canon-aplio-i800-ultrasound',
    category: 'Ultrasound',
    condition: 'Refurbished',
    price: 88000,
    description: 'The Canon Aplio i800 Ultrasound system delivers premium imaging performance with its iSMC technology and advanced transducer portfolio. It provides exceptional detail resolution and penetration for demanding clinical applications including cardiology, abdominal, and vascular imaging. This refurbished system has been fully reconditioned with new transducers and updated software.',
    specs: '{"Transducer Ports":"3 active ports","Display":"23.8" HD LED monitor","Imaging Modes":"B-mode, Harmonic, Doppler, Elastography","Frame Rate":"Up to 400 fps","Storage":"512 GB SSD","Connectivity":"DICOM, USB, HDMI, Ethernet","Weight":"280 lbs","Channels":"256 digital channels"}',
    features: '["iSMC micro-scanning technology","Shear Wave elastography","Automated measurements with ApliPure+","Contrast-enhanced ultrasound (CEUS)","Panoramic and 3D/4D imaging","Intelligent workflow automation"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: false,
    createdAt: '2025-03-15T10:00:00.000Z',
  },
  {
    id: 'fp-9',
    name: 'Topcon Maestro 2 OCT',
    slug: 'topcon-maestro-2-oct',
    category: 'Ophthalmology',
    condition: 'New',
    price: 68000,
    description: 'The Topcon Maestro 2 is a fully automated, multi-modal diagnostic platform combining OCT, fundus photography, and FA in one compact device. It features swept-source OCT technology for deeper penetration and higher quality retinal images. The system\'s automated alignment and tracking eliminate the need for operator intervention, improving workflow efficiency. Ideal for busy ophthalmology practices and screening programs.',
    specs: '{"OCT Technology":"Swept-source OCT (1,050 nm)","Scan Speed":"50,000 A-scans/second","Axial Resolution":"8 \u03bcm","Scan Width":"12 mm x 9 mm","Fundus Camera":"TrueColor confocal","Visual Fields":"Optional 24-2, 10-2","FA Capability":"Optional fluorescein angiography","Automation":"Fully automated alignment and capture"}',
    features: '["Swept-source OCT for deeper penetration","Fully automated operation","Combined OCT + fundus camera","Built-in normative database","Single-button multi-modal capture","Compact footprint design"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: true,
    createdAt: '2025-03-20T10:00:00.000Z',
  },
  {
    id: 'fp-10',
    name: 'Shimadzu Sonialvision X-Ray',
    slug: 'shimadzu-sonialvision-x-ray',
    category: 'X-Ray',
    condition: 'Refurbished',
    price: 145000,
    description: 'The Shimadzu Sonialvision is a flat-panel digital radiography and fluoroscopy system designed for multi-purpose diagnostic imaging. It seamlessly handles general radiography, fluoroscopy, and spot imaging in a single system. The 17 x 17 inch flat-panel detector provides excellent image quality with reduced dose. This refurbished unit is perfect for orthopedic, gastrointestinal, and interventional imaging needs.',
    specs: '{"Generator":"80 kW high-frequency","Detector":"17" x 17" flat-panel (FPD)","Fluoroscopy":"Real-time digital fluoroscopy","Spot Imaging":"Digital spot radiography","Table":"Multi-directional tilting table","SID Range":"40-60 inches","Dose Management":"SUREexposure technology","Software":"Console with integrated PACS"}',
    features: '["Flat-panel detector for both R/F","Real-time digital fluoroscopy","Multi-purpose tilting table","Low-dose imaging with SUREexposure","Automatic collimation control","Integrated DICOM connectivity"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: false,
    createdAt: '2025-04-01T10:00:00.000Z',
  },
  {
    id: 'fp-11',
    name: 'GE LOGIQ E10 Ultrasound',
    slug: 'ge-logiq-e10-ultrasound',
    category: 'Ultrasound',
    condition: 'New',
    price: 110000,
    description: 'The GE LOGIQ E10 represents the next generation of ultrasound imaging with its revolutionary cSound architecture and high channel count. It delivers extraordinary image clarity and consistency across a wide range of clinical applications. The system features advanced AI-powered tools for automated measurements and image optimization. Designed for radiology, OB/GYN, vascular, and point-of-care applications.',
    specs: '{"Transducer Ports":"4 active ports","Display":"23.8" HD LED monitor + 12.1" touchscreen","Architecture":"cSound beamformer","Channels":"128 digital channels","Imaging Modes":"B-mode, Harmonic, Doppler, Strain Elastography","Storage":"1 TB SSD","Connectivity":"DICOM, USB, Wi-Fi, Ethernet","Weight":"330 lbs"}',
    features: '["cSound architecture for superior imaging","AI-powered image optimization (Auto B-mode)","Strain elastography for tissue characterization","B-Flow and B-Steer technologies","Modern ergonomic design","Comprehensive vascular and cardiac tools"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: false,
    createdAt: '2025-04-10T10:00:00.000Z',
  },
  {
    id: 'fp-12',
    name: 'Heidelberg Spectralis OCT',
    slug: 'heidelberg-spectralis-oct',
    category: 'Ophthalmology',
    condition: 'Refurbished',
    price: 58000,
    description: 'The Heidelberg Spectralis OCT is renowned for its proprietary TruTrack active eye-tracking and dual-beam technology that delivers follow-up scans with pixel-perfect reproducibility. It is the preferred choice for longitudinal monitoring of retinal diseases and glaucoma progression. This refurbished unit has been completely overhauled with current software and calibration.',
    specs: '{"OCT Technology":"Spectral-domain OCT (870 nm)","Scan Speed":"40,000 A-scans/second","Axial Resolution":"3.9 \u03bcm","Transverse Resolution":"14 \u03bcm","Eye Tracking":"TruTrack active eye tracking","Fundus Camera":"Confocal scanning laser ophthalmoscope","FA/ICG":"Optional angiography module","Display":"24" medical-grade monitor"}',
    features: '["TruTrack dual-beam eye tracking","Pixel-perfect follow-up scanning","BluePeak autofluorescence","OCT-Angiography upgradeable","Anatomical mapping with eye tracking","Widefield imaging module available"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: false,
    createdAt: '2025-04-15T10:00:00.000Z',
  },
  {
    id: 'fp-13',
    name: 'GE Optima XR646 X-Ray',
    slug: 'ge-optima-xr646-x-ray',
    category: 'X-Ray',
    condition: 'Refurbished',
    price: 92000,
    description: 'The GE Optima XR646 is a reliable digital radiography system built for general-purpose imaging in hospitals and clinics. It features a floor-mounted tube stand and wall stand configuration for maximum flexibility. The AutoImage suite automatically optimizes every image for consistent diagnostic quality. This refurbished system is an excellent workhorse for facilities needing dependable daily radiography.',
    specs: '{"Generator":"65 kW high-frequency","Detector":"Wireless 35 x 43 cm DR panel","Tube":"Dual-focus anode","Collimation":"Automatic multi-leaf","SID Range":"40-72 inches","Wall Stand":"Motorized elevating","Table":"4-way floating tabletop","Software":"AutoImage processing suite"}',
    features: '["AutoImage automatic image processing","Wireless DR detector convenience","Flexible room configurations","DoseWatch dose monitoring","DICOM 3.0 connectivity","Consistent image quality"]',
    imageUrl: '/images/placeholder-equipment.svg',
    images: '["/images/placeholder-equipment.svg"]',
    status: 'active',
    isFeatured: false,
    createdAt: '2025-04-20T10:00:00.000Z',
  },
];

/* ── Filter helper for fallback data ── */
function filterFallbackProducts(
  products: typeof FALLBACK_PRODUCTS,
  opts: { category?: string; condition?: string; search?: string; featured?: string; status: string }
) {
  let filtered = products.filter((p) => p.status === opts.status);

  if (opts.category) {
    filtered = filtered.filter((p) => p.category === opts.category);
  }
  if (opts.condition) {
    filtered = filtered.filter((p) => p.condition === opts.condition);
  }
  if (opts.featured === 'true') {
    filtered = filtered.filter((p) => p.isFeatured);
  }
  if (opts.search) {
    const q = opts.search.toLowerCase();
    filtered = filtered.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
    );
  }

  return filtered;
}

/* ═══════════════════════════════════════════════════════ */

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const category = searchParams.get('category');
  const condition = searchParams.get('condition');
  const search = searchParams.get('search');
  const featured = searchParams.get('featured');
  const status = searchParams.get('status') || 'active';
  const page = parseInt(searchParams.get('page') || '1', 10);
  const limit = parseInt(searchParams.get('limit') || '20', 10);
  const sort = searchParams.get('sort') || 'createdAt';
  const order = searchParams.get('order') || 'desc';

  // Try database first
  try {
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = { status };

    if (category) where.category = category;
    if (condition) where.condition = condition;
    if (featured === 'true') where.isFeatured = true;
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { description: { contains: search } },
        { category: { contains: search } },
      ];
    }

    const orderBy: Record<string, string> = {};
    if (sort === 'price' && order === 'asc') orderBy.price = 'asc';
    else if (sort === 'price') orderBy.price = 'desc';
    else if (sort === 'name') orderBy.name = order === 'asc' ? 'asc' : 'desc';
    else orderBy.createdAt = order === 'asc' ? 'asc' : 'desc';

    const [products, total] = await Promise.all([
      db.product.findMany({ where, orderBy, skip, take: limit }),
      db.product.count({ where }),
    ]);

    return NextResponse.json({
      products,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    });
  } catch (dbError) {
    console.warn('DB unavailable, using fallback products:', (dbError as Error).message);

    // Fallback: use embedded data
    let filtered = filterFallbackProducts(FALLBACK_PRODUCTS, {
      category: category || undefined,
      condition: condition || undefined,
      search: search || undefined,
      featured: featured || undefined,
      status,
    });

    // Sort
    filtered.sort((a, b) => {
      if (sort === 'price') {
        return order === 'asc'
          ? (a.price || 0) - (b.price || 0)
          : (b.price || 0) - (a.price || 0);
      }
      if (sort === 'name') {
        return order === 'asc' ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name);
      }
      return order === 'asc'
        ? new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
        : new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    // Paginate
    const total = filtered.length;
    const skip = (page - 1) * limit;
    const paginated = filtered.slice(skip, skip + limit);

    return NextResponse.json({
      products: paginated,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      name, slug, category, condition, price, description,
      specs, features, imageUrl, images, status, isFeatured,
    } = body;

    if (!name || !slug || !category || !condition || !description) {
      return NextResponse.json(
        { error: 'Missing required fields: name, slug, category, condition, description' },
        { status: 400 }
      );
    }

    const existing = await db.product.findUnique({ where: { slug } });
    if (existing) {
      return NextResponse.json(
        { error: 'A product with this slug already exists' },
        { status: 409 }
      );
    }

    const product = await db.product.create({
      data: {
        name, slug, category, condition,
        price: price ?? null,
        description,
        specs: typeof specs === 'string' ? specs : JSON.stringify(specs || {}),
        features: typeof features === 'string' ? features : JSON.stringify(features || []),
        imageUrl: imageUrl || '/images/placeholder-equipment.svg',
        images: typeof images === 'string' ? images : JSON.stringify(images || []),
        status: status || 'active',
        isFeatured: isFeatured || false,
      },
    });

    return NextResponse.json({ product }, { status: 201 });
  } catch (error) {
    console.error('Error creating product:', error);
    return NextResponse.json(
      { error: 'Failed to create product' },
      { status: 500 }
    );
  }
}
